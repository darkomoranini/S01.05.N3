import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;

public class EncriptarDesencriptar {
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
    private static final String KEY = "pQ@G7HSE9>mGt>?$";
    private static final String IV = "vector_inicialll";

    public static void main(String[] args) {
       
    	String inputFile = "/Users/darkomorandini/Desktop/eclipse/ARCHIVOS EXT/Countries.txt";
        String encryptedFile = "/Users/darkomorandini/Desktop/eclipse/ARCHIVOS EXT/EncryptedCountries.txt";
        String decryptedFile = "/Users/darkomorandini/Desktop/eclipse/ARCHIVOS EXT/DecryptedCountries.txt";

        try {
           
            encryptFile(inputFile, encryptedFile);
            
            decryptFile(encryptedFile, decryptedFile);

            System.out.println("Encriptado y desencriptado realizado correctamente.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void encryptFile(String inputFile, String outputFile) throws Exception {
        processFile(inputFile, outputFile, Cipher.ENCRYPT_MODE);
    }

    public static void decryptFile(String inputFile, String outputFile) throws Exception {
        processFile(inputFile, outputFile, Cipher.DECRYPT_MODE);
    }

    private static void processFile(String inputFile, String outputFile, int cipherMode) throws Exception {
        Path inputPath = Paths.get(inputFile);
        Path outputPath = Paths.get(outputFile);

        SecretKeySpec secretKey = new SecretKeySpec(KEY.getBytes(), ALGORITHM);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(IV.getBytes());
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(cipherMode, secretKey, ivParameterSpec);

        try (InputStream inputStream = new FileInputStream(inputPath.toFile());
             OutputStream outputStream = new FileOutputStream(outputPath.toFile())) {
            byte[] inputBytes = Files.readAllBytes(inputPath);
            byte[] outputBytes = cipher.doFinal(inputBytes);
            outputStream.write(outputBytes);
        } catch (IOException e) {
            throw new IOException("Error al procesar el archivo: " + e.getMessage());
        }
    }
}